. ./comm.sh

IMAGE=`ls -lt /home/mysql/backup/full/*/*.img|sed -n '1 p'|awk '{print $9;}'`

mysqlbackup --host=127.0.0.1 --user=root -pmysql --protocol=tcp \
	--port=3306  \
	--incremental \
	--incremental-base=dir:`dirname ${IMAGE}` \
	--backup-dir=/home/mysql/backup/inc --with-timestamp \
	--backup-image=image3306inc.img \
	backup-to-image
