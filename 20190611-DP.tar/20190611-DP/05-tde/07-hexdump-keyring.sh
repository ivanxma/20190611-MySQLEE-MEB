
echo "3306 -  hexdump /home/mysql/data/3306/mysql-keyring/keyring-encrypted"
hexdump /home/mysql/data/3306/mysql-keyring/keyring-encrypted
echo "Press <ENTER> to continue"
read

echo "3316 -  hexdump /home/mysql/data/3316/mysql-keyring/keyring-encrypted"
hexdump /home/mysql/data/3316/mysql-keyring/keyring-encrypted
echo "Press <ENTER> to continue"
read

echo "3326 -  hexdump /home/mysql/data/3326/mysql-keyring/keyring-encrypted"
hexdump /home/mysql/data/3326/mysql-keyring/keyring-encrypted
