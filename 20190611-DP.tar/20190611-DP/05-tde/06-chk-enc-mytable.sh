. ./comm.sh


strings /home/mysql/data/3306/mydb2/mytable_enc.ibd
